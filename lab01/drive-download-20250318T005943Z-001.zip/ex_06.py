# print(5*1) # 5
# print(5*2) # 5+5
# print(5*3) # 5+5+5
# print(5*4)
# print(5*5)
# print(5*6)
# print(5*7)
# print(5*8)
# print(5*9)

x = 5
print(x)

x = x+5
print(x)

x = x+5
print(x)

x = x+5
print(x)

x = x+5
print(x)

x = x+5
print(x)

x = x+5
print(x)

x = x+5
print(x)

x = x + 5
print(x)
