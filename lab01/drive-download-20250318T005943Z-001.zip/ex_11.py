# ex_11.py
height = float( input("키(m):") )
weight = float( input("몸무게(kg): ") )

bmi = weight / (height**2)
print("BMI: ", bmi)