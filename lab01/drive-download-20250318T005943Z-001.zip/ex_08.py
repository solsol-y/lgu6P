# ex_08.py
name = input("이름을 입력하세요: ")
color = input("좋아하는 색을 입력하세요: ")

print(f"{name}님의 가장 좋아하는 색은 {color}입니다.")
print(name, "님의 가장 좋아하는 색은 ", color, "입니다.")
print(name + "님의 가장 좋아하는 색은 " + color + "입니다.")