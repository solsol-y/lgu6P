# ex_13.py

composer1 = 'Beethoven'
composer2 = 'Bach'
composer3 = "Mozart"

print(f"I love {composer1}'s Symphony No.3 'Eroica'.")
print(f"I love {composer2}'s Goldberg Variation.")
print(f"I love {composer3}'s Die Zauberflöte")

