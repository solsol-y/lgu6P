a = '100'
b = "foo"
c = 300

print(a, end='')
print(b, end='')
print(c, end='')

print('foo', 'bar', 'egg', sep=' ')
print(a, b, c)