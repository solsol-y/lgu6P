# ex_eq.py

a = float(input("a: "))
b = float(input("b: "))
c = float(input("c: "))
x = float(input("x: "))

y1 = a * x + b
print(y1)

y2 = a * x**2 + b * x + c
print(y2)