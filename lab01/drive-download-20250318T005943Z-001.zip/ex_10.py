# ex_10.py

a = int( input("첫번째 숫자 입력: ") )
b = int( input("두번째 숫자 입력: ") )
     
# print(a, b)
# print(type(a), type(b))
   
print("두 수의 합: ", a+b)
print("두 수의 차: ", a-b)
print("두 수의 곱: ", a*b)
print("두 수의 비: ", a/b)


