# ex_09.py

a = input("첫번째 숫자 입력: ")
b = input("두번째 숫자 입력: ")
 
print(a, b)
print(type(a), type(b))

print("두 수의 합: ", a+b)
print("두 수의 차: ", a-b)


